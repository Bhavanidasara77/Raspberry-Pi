from machine import Pin
import utime

led1=Pin(14,Pin.OUT)
led2=Pin(15,Pin.OUT)
while True:
  led1.toggle()
  led2.toggle()
  utime.sleep(2)
