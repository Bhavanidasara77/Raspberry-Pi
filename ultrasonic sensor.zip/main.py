from machine import Pin
import utime
trigger=Pin(3,Pin.OUT)
echo=Pin(2,Pin.IN)
def ultra():
  trigger.low()
  utime.sleep_us(2)
  trigger.high()
  utime.sleep_us(5)
  trigger.low()
  while echo.value()==0:
    singaloff=utime.ticks_us()
  while echo.value()==1:
    singalon=utime.ticks_us()
  timepassed=singalon-singaloff
  distance=(timepassed*0.0343)/2
  print("The distance from object is ",distance,"cm")
while True:
  ultra()
  utime.sleep(1)
